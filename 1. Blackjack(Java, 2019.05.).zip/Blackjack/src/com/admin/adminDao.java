package com.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.admin.DBConnect;
import com.admin.adminDao;
import com.admin.adminDto;

public class adminDao {
   private static adminDao dao;
   private adminDao() {}
   public static adminDao getInstance() {
      if (dao == null) {
         dao = new adminDao();
      }
      return dao;
   }
   
   public boolean insert(adminDto dto) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      boolean isSuccess = false;
      try {
         conn = new DBConnect().getConn();
         String sql = "INSERT INTO REC (ID, WINS)" +
                   "VALUES(?, ?)";
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1,  dto.getId());
         pstmt.setInt(2,  dto.getWins());
         int flag = pstmt.executeUpdate();
         if (flag > 0) {
            isSuccess = true;
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
         } catch (Exception e) {}
      }
      return isSuccess;
   }
   
   public List<adminDto> getList() {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      List<adminDto> list = new ArrayList<adminDto>();
      try {
         conn = new DBConnect().getConn();
         String sql = "SELECT ID, MAX(WINS) FROM REC GROUP BY ID ORDER BY MAX(WINS) DESC"; //동일 ID를 그룹으로 묶고 그 중 점수가 가장 높은 것을 가져오도록 함.
         																					// 이전 문장: "SELECT * FROM REC ORDER BY WINS DESC" + 트리거를 이용해서 //Trigger보다 좋은 점은, 누군가 ID를 바꿨는데 그게 기존의  ID와 겹치는 경우, DB에 기록이 남기 때문에 관리자가 DB에 접속해서 수정할 수 있다. 그러나 TRIGGER는 기록이 남지 않아 이것이 불가능하다. 
         pstmt = conn.prepareStatement(sql);
         rs = pstmt.executeQuery();
         while(rs.next()) {
            String id = rs.getString("id");
            int wins = rs.getInt("max(wins)");
            adminDto dto = new adminDto(id, wins);
            list.add(dto);
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
         } catch (Exception e) {}
      }
      return list;
   }
   
   public boolean update(String n_id, String o_id) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      boolean isSuccess = false;
      try {
         conn = new DBConnect().getConn();
         String sql = "UPDATE REC SET ID = ? WHERE ID = ?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, n_id);
         pstmt.setString(2, o_id);
         int flag = pstmt.executeUpdate();
         if (flag > 0) {
            isSuccess = true;
         } 
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
         } catch (Exception e) {}
      }
      return isSuccess;
   }
   
   public boolean delete(String id) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      boolean isSuccess = false;
      try {
         conn = new DBConnect().getConn();
         String sql = "DELETE FROM REC WHERE ID = ?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1,  id);
         int flag = pstmt.executeUpdate();
         if (flag > 0) {
            isSuccess = true;
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
         } catch (Exception e) {}
      }
      return isSuccess;
   }
   
}