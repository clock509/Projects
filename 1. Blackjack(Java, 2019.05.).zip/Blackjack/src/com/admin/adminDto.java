package com.admin;

public class adminDto {
   private String id;
   private int wins;
   
   public adminDto() {}

   public adminDto(String id, int wins) {
      super();
      this.id = id;
      this.wins = wins;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public int getWins() {
      return wins;
   }

   public void setWins(int wins) {
      this.wins = wins;
   }
   
   
}